package com.product.management.Exception;

public class ProductNotFoundException extends RuntimeException{
	ProductNotFoundException(){
		
	}
	public ProductNotFoundException(String s) {
		super(s);
	}

}
