package com.product.management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.management.entity.Product;
import com.product.management.repository.IProductRepository;

@Service
public class ProductImpl implements IProductService {
	
	@Autowired
	private IProductRepository prodRepo;

	@Override
	public Product saveProduct(Product product) {
		
		return prodRepo.save(product);
	}

	@Override
	public List<Product> getProducts() {
		
		return prodRepo.findAll();
	}

	@Override
	public Product getProductById(int id) {
		
		return prodRepo.findById(id).orElse(null);
	}

	@Override
	public String deleteProductByid(int id) {
		
		prodRepo.deleteById(id);
		return "Product deleted for id number"+id;
	}

	@Override
	public Product updateProduct(Product product) {
		Product existingProduct =  prodRepo.findById(product.getId()).orElse(null);
		existingProduct.setName(product.getName());
		existingProduct.setQuantity(product.getQuantity());
		existingProduct.setPrice(product.getPrice());
		return prodRepo.save(existingProduct);
	}
	
	

}
