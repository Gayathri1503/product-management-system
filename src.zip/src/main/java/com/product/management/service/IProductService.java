package com.product.management.service;

import java.util.List;

import com.product.management.entity.Product;

public interface IProductService {
	
	public Product saveProduct(Product product);
	public List<Product> getProducts();
	public Product updateProduct(Product product);
	public Product getProductById(int id);
	public String deleteProductByid(int id);
	
	
	

}
