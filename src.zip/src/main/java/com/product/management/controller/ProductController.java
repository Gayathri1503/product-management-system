package com.product.management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.product.management.Exception.ProductNotFoundException;
import com.product.management.entity.Product;
import com.product.management.service.ProductImpl;

@RestController
@RequestMapping("/productManagement")
public class ProductController {
	
	@Autowired
	private ProductImpl prodService;
	
	@PostMapping("/addProduct")
	public Product addProduct(@RequestBody Product product) {
		return prodService.saveProduct(product);
	}
	
	@GetMapping("/AllProducts")
	public List<Product> findAllProducts(){
		return prodService.getProducts();
	}
	
	@GetMapping("/ProductById/{id}")
	public ResponseEntity<Product> findProductById(@PathVariable int id) {
		try {
			Product prod =  prodService.getProductById(id);
			return new ResponseEntity<Product>(prod,HttpStatus.OK);
		}
		catch(ProductNotFoundException e)
		{
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}
		
	}
	
	@PutMapping("/update")
	public Product updateProduct(@RequestBody Product prduct) {
		return prodService.updateProduct(prduct);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deletePrdouct(int id) {
		return prodService.deleteProductByid(id);
		
	}
	
	

}
