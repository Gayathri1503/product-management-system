package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;



import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.List;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.product.management.ProductManagementSystemApplication;
import com.product.management.entity.Product;
import com.product.management.repository.IProductRepository;

@SpringBootTest(classes =ProductManagementSystemApplication.class)
//@TestMethodOrder(OrderAnnotation.class)
class ProductManagementSystemApplicationTests {
	
	@Autowired
	private IProductRepository pRepo;

	@Test
 @Order(1)
	public void testCreate() {
		Product p = new Product();
		p.setId(1);
		p.setName("samsung");
		p.setPrice(12000);
		p.setQuantity(4);
		pRepo.save(p);
		assertNotNull(pRepo.findById(1).get());
		
	}
	
	@Test
	//@Order(2)
	public void testReadAll() {
		java.util.List<Product> list = pRepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	
	@Test
	//@Order(3)		
	public void testSingleProduct() {
		Product product = pRepo.findById(1).get();
		assertEquals(12000,product.getPrice());
		
	}
	
	@Test
	//@Order(4)
	public void testUpdate() {
		Product p = pRepo.findById(1).get();
		p.setPrice(10000);
		pRepo.save(p);
		assertNotEquals(12000, pRepo.findById(1).get().getPrice());
	}
	
	@Test
	@Order(5)
	public void testDelete() {
		pRepo.deleteById(1);
		assertThat(pRepo.existsById(1)).isFalse();
	}
	

}
